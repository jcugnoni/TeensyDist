%function all_lines = buildDocs(nodes,pname_orig,pname_new)

%if nargin 

%build empty docs for 